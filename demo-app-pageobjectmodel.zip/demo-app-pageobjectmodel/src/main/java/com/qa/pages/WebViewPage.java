package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.qa.basePage.BasePage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
/**
 * 
 * @author Rama krishna
 * 
 *
 */
public class WebViewPage extends BasePage {

	private AppiumDriver<AndroidElement> driver;

	public WebViewPage() {
	}

	

	@AndroidFindBy(className = "android.widget.Button")
	private MobileElement clickAndroidButton;
	
	/**
	 * 
	 *initialize WebiewPage Elements
	 * 
	 *
	 */
	
	
	public WebViewPage(AppiumDriver<AndroidElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	/**
	 * 
	 *perform Click Action on Top Right side x Button
	 * 
	 *
	 */
	public void clickOnAndroidButton() {

		clickAndroidButton.click();

	}
	/**
	 * given the Starting Page element and Ending Page Element
	 * perform the VerticallScrolling action untill get a End of The page
	 *
	 */

	public void scrollUpToBottomOfThePage() {
		By startingPage = By.xpath("//*[@text='webdriverio']");
		By endOfPage = By.xpath("//*[@text='Copyright © 2020 OpenJS Foundation']");

		scrollToElement(startingPage, "down");
		driver.findElement(startingPage).isDisplayed();
		scrollToElement(endOfPage, "Up");
		driver.findElement(endOfPage).isDisplayed();
	}

}

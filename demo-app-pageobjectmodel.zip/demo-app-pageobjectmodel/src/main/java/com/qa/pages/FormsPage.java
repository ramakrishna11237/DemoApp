package com.qa.pages;

import org.openqa.selenium.support.PageFactory;

import com.qa.basePage.BasePage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
/**
 * 
 * @author Rama krishna
 * 
 *
 */
public class FormsPage extends BasePage {

	private AppiumDriver<AndroidElement> driver;

	public FormsPage() {
	}


	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='Forms']")
	private AndroidElement clickOnFormsButton;

	@AndroidFindBy(accessibility = "text-input")
	private AndroidElement enterText;

	@AndroidFindBy(accessibility = "switch")
	private AndroidElement clickOnSwitchButton;

	@AndroidFindBy(accessibility = "select-Dropdown")
	private AndroidElement clickOnDropdownButton;

	@AndroidFindBy(xpath = "//*[@text='Appium is awesome']")
	private AndroidElement clickOnwebdriverText;

	@AndroidFindBy(accessibility = "button-Active")
	private AndroidElement clickOnActiveButton;

	@AndroidFindBy(id = "android:id/button1")
	private AndroidElement clickOnOkButton;

	@AndroidFindBy(accessibility = "Swipe")
	private MobileElement clickOnSwipeButton;
	/**
	 * 
	 * initialize formsPage Elements
	 * 
	 *
	 */

	public FormsPage(AppiumDriver<AndroidElement> driver) {
		this.setDriver(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	/**
	 * perform The Click Action on FormsPage
	 * fill The Text Field 
	 * perform click action on switch, switch is turn On
	 * 
	 */

	public void clickTheFormButtonAndEnterTheText() throws InterruptedException {
		clickOnFormsButton.click();
		enterText.sendKeys("Ramakrishna");
		clickOnSwitchButton.click();
	}
	/**
	 * perform Vertical Scrolling Up to Get DropDown button
	 *
	 */

	public FormsPage swipeVertically() {

		verticalScroll();
		return null;

	}
	/**
	 * perform click action on dropdown button
	 * select the webDriver Text
	 * perform click action on Active Button
	 * click on Ok Button, know button is active
	 *click on swipe Button, entering To Swipe Page
	 *
	 */
	public SwipePage fillTheFormsPageAndEnterToSwipePage() {
		
		clickOnDropdownButton.click();
		clickOnwebdriverText.click();
		clickOnActiveButton.click();
		clickOnOkButton.click();
		clickOnSwipeButton.click();
		return new SwipePage();
	}
	public AppiumDriver<AndroidElement> getDriver() {
		return driver;
	}
	public void setDriver(AppiumDriver<AndroidElement> driver) {
		this.driver = driver;
	}

}

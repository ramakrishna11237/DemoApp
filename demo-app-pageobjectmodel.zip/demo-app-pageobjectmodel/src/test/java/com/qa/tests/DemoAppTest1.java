package com.qa.tests;

import java.net.MalformedURLException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.basePage.BasePage;
import com.qa.pages.FormsPage;
import com.qa.pages.SwipePage;
import com.qa.pages.WebViewPage;

public class DemoAppTest1 extends BasePage {
	FormsPage Formspage;
	SwipePage Swipepage;
	WebViewPage WebViewPage;

	public DemoAppTest1() {
		super();
	}

	@BeforeMethod
	public void demoAppLaunchInAndroid() throws MalformedURLException {
		setUp();

		Formspage = new FormsPage(driver);
		Swipepage = new SwipePage(driver);
		WebViewPage = new WebViewPage(driver);

	}

	@Test
	public <Scrolling> void demoAppTest() throws InterruptedException {
		Formspage.clickTheFormButtonAndEnterTheText();
		
		Formspage.swipeVertically();
		
		Thread.sleep(1000);
		Formspage.fillTheFormsPageAndEnterToSwipePage();
		
		Swipepage.swipeHorizontally();

		Swipepage.clickOnWebViewButtonAndEnterToWebViewPage();
		
		Thread.sleep(1000);

		WebViewPage.clickOnAndroidButton();
		
		WebViewPage.scrollUpToBottomOfThePage();

	}

}

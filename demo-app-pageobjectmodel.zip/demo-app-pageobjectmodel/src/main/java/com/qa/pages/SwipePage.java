package com.qa.pages;

import org.openqa.selenium.support.PageFactory;

import com.qa.basePage.BasePage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
/**
 * 
 * @author Rama krishna
 * 
 *
 */
public class SwipePage extends BasePage {
	private AppiumDriver<AndroidElement> driver;

	public SwipePage() {
	}

	

	@AndroidFindBy(accessibility = "WebView")
	private MobileElement clickOnWebViewButton;
	
	/**
	 * 
	 * initialize swipePage elements
	 * 
	 *
	 */
	
	public SwipePage(AppiumDriver<AndroidElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	
	/**
	 * 
	 * performing  Swipe Action Horizontally up to end of the page
	 * 
	 *
	 */
	public SwipePage swipeHorizontally() {

		horizontalScrollToElement();
		return null;

	}


	/**
	 * 
	 * performing the click action on WebViewButton , showing WebViewPage
	 * 
	 *
	 */

	public WebViewPage clickOnWebViewButtonAndEnterToWebViewPage() {
		clickOnWebViewButton.click();
		return new WebViewPage();
	}


	public AppiumDriver<AndroidElement> getDriver() {
		return driver;
	}


	public void setDriver(AppiumDriver<AndroidElement> driver) {
		this.driver = driver;
	}

}
